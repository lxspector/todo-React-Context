import { UserPersonalInfo, UserContacts } from './components/index'; // Assuming 'index.jsx' is the file name

export const UserBlock = ({ name, age, email, phone }) => {
  return (
    <div>
      <h2>пользователь</h2>
      <UserPersonalInfo name={name} age={age} />
      <UserContacts email={email} phone={phone} />
    </div>
  );
};
